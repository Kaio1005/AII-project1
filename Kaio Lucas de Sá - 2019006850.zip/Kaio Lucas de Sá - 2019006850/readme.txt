para a execução do código do tp navegue até o diretório do programa e digite no terminal

python TP1.py

Seguido da entrada no formato descrito nas especificações do trabalho: Algoritmo Estado_Inicial PRINT
Caso o sistema tenha mais de uma versão do python instalada, saiba que o programa foi confeccionado usando python 3, e portanto para conseguir executá-lo digite

python3 TP1.py

Seguido da entrada no formato descrito nas especificações do trabalho: Algoritmo Estado_Inicial PRINT